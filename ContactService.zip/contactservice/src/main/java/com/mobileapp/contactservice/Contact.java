package com.mobileapp.contactservice;

/**
 * Represents a contact with a unique identifier and associated information.
 * <p>
 * The contact ID is immutable and cannot be longer than 10 characters. All fields are validated 
 * upon creation or update to ensure they meet specified criteria.
 */
public class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    /**
     * Constructs a new Contact with validated parameters.
     *
     * @param contactId Unique identifier (1-10 characters, not null)
     * @param firstName First name (1-10 characters, not null)
     * @param lastName Last name (1-10 characters, not null)
     * @param phone Exactly 10 numeric digits (not null)
     * @param address Address (1-30 characters, not null)
     * @throws IllegalArgumentException If any parameter is invalid
     */
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        validateContactId(contactId);
        validateFirstName(firstName);
        validateLastName(lastName);
        validatePhone(phone);
        validateAddress(address);

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    // Validation Methods
    private void validateContactId(String contactId) {
        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Invalid Contact ID");
        }
    }

    private void validateFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid First Name");
        }
    }

    private void validateLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid Last Name");
        }
    }

    private void validatePhone(String phone) {
        if (phone == null || !phone.matches("^\\d{10}$")) {
            throw new IllegalArgumentException("Invalid Phone Number");
        }
    }

    private void validateAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid Address");
        }
    }

    // Getters and Setters with Validation
    public String getContactId() { return contactId; }

    public String getFirstName() { return firstName; }

    /**
     * Updates the first name with validation.
     *
     * @param firstName New first name (1-10 characters, not null)
     * @throws IllegalArgumentException If invalid
     */
    public void setFirstName(String firstName) {
        validateFirstName(firstName);
        this.firstName = firstName;
    }

    public String getLastName() { return lastName; }

    /**
     * Updates the last name with validation.
     *
     * @param lastName New last name (1-10 characters, not null)
     * @throws IllegalArgumentException If invalid
     */
    public void setLastName(String lastName) {
        validateLastName(lastName);
        this.lastName = lastName;
    }

    public String getPhone() { return phone; }

    /**
     * Updates the phone number with validation.
     *
     * @param phone New phone number (exactly 10 digits, not null)
     * @throws IllegalArgumentException If invalid
     */
    public void setPhone(String phone) {
        validatePhone(phone);
        this.phone = phone;
    }

    public String getAddress() { return address; }

    /**
     * Updates the address with validation.
     *
     * @param address New address (1-30 characters, not null)
     * @throws IllegalArgumentException If invalid
     */
    public void setAddress(String address) {
        validateAddress(address);
        this.address = address;
    }
}




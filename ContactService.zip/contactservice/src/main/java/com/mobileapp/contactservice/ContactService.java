package com.mobileapp.contactservice;

import java.util.HashMap;
import java.util.Map;

/**
 * Manages a collection of contacts with unique IDs, providing CRUD operations.
 */
public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    /**
     * Adds a new contact to the service.
     *
     * @param contact Contact to add (not null)
     * @throws IllegalArgumentException If contact ID already exists
     */
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }
        String contactId = contact.getContactId();
        if (contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID '" + contactId + "' already exists");
        }
        contacts.put(contactId, contact);
    }

    /**
     * Removes a contact by ID.
     *
     * @param contactId ID of the contact to remove
     * @throws IllegalArgumentException If contact ID not found
     */
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.remove(contactId);
    }

    /**
     * Updates specified fields of an existing contact.
     *
     * @param contactId ID of the contact to update
     * @param firstName New first name (optional)
     * @param lastName New last name (optional)
     * @param phone New phone number (optional)
     * @param address New address (optional)
     * @throws IllegalArgumentException If contact ID not found or any update is invalid
     */
    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }

        if (firstName != null) contact.setFirstName(firstName);
        if (lastName != null) contact.setLastName(lastName);
        if (phone != null) contact.setPhone(phone);
        if (address != null) contact.setAddress(address);
    }
}





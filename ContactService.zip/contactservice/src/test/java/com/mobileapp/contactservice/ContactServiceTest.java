package com.mobileapp.contactservice;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the ContactService class, verifying contact management operations.
 */
class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    @DisplayName("Set up a new ContactService before each test")
    void setUp() {
        service = new ContactService();
    }

    @Test
    @DisplayName("Test adding a duplicate contact")
    void testAddDuplicateContact() {
        Contact contact = new Contact("C789", "Dave", "Brown", "1122334455", "321 Elm St");
        
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> 
            service.addContact(contact), 
            "Adding duplicate contact ID should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test adding null contact")
    void testAddNullContact() {
        assertThrows(IllegalArgumentException.class, () -> 
            service.addContact(null), 
            "Adding null contact should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test deleting existing contact")
    void testDeleteExistingContact() {
        Contact contact = new Contact("C789", "Dave", "Brown", "1122334455", "321 Elm St");
        service.addContact(contact);
        service.deleteContact("C789");
        assertThrows(IllegalArgumentException.class, () -> 
            service.updateContact("C789", "Dave", "Brown", "1122334455", "321 Elm St"),
            "Updating deleted contact should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test deleting already deleted contact")
    void testDeleteNonExistentContactAfterDeletion() {
        Contact contact = new Contact("C789", "Dave", "Brown", "1122334455", "321 Elm St");
        
        service.addContact(contact);
        service.deleteContact("C789");
        assertThrows(IllegalArgumentException.class, () -> 
            service.deleteContact("C789"), 
            "Deleting non-existent contact after deletion should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test deleting non-existent contact")
    void testDeleteNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> 
            service.deleteContact("INVALID_ID"), 
            "Deleting non-existent contact should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test updating contact first name")
    void testUpdateContactFirstName() {
        Contact contact = new Contact("C012", "Eve", "Jones", "2233445566", "654 Spruce Blvd");
        
        service.addContact(contact);
        service.updateContact("C012", "Evelyn", "Smith", "3344556677", "New Address");
        
        assertEquals("Evelyn", contact.getFirstName(), "First name should be updated");
    }

    @Test
    @DisplayName("Test updating contact last name")
    void testUpdateContactLastName() {
        Contact contact = new Contact("C012", "Eve", "Jones", "2233445566", "654 Spruce Blvd");
        
        service.addContact(contact);
        service.updateContact("C012", "Evelyn", "Smith", "3344556677", "New Address");
        
        assertEquals("Smith", contact.getLastName(), "Last name should be updated");
    }

    @Test
    @DisplayName("Test updating contact phone")
    void testUpdateContactPhone() {
        Contact contact = new Contact("C012", "Eve", "Jones", "2233445566", "654 Spruce Blvd");
        
        service.addContact(contact);
        service.updateContact("C012", "Evelyn", "Smith", "3344556677", "New Address");
        
        assertEquals("3344556677", contact.getPhone(), "Phone should be updated");
    }

    @Test
    @DisplayName("Test updating contact address")
    void testUpdateContactAddress() {
        Contact contact = new Contact("C012", "Eve", "Jones", "2233445566", "654 Spruce Blvd");
        
        service.addContact(contact);
        service.updateContact("C012", "Evelyn", "Smith", "3344556677", "New Address");
        
        assertEquals("New Address", contact.getAddress(), "Address should be updated");
    }

    @Test
    @DisplayName("Test partial update keeps unchanged last name")
    void testPartialUpdateLastNameUnchanged() {
        Contact contact = new Contact("C012", "Eve", "Jones", "2233445566", "654 Spruce Blvd");
        
        service.addContact(contact);
        service.updateContact("C012", "Evelyn", null, null, "New Address");
        
        assertEquals("Jones", contact.getLastName(), "Last name should remain unchanged");
    }

    @Test
    @DisplayName("Test partial update keeps unchanged phone")
    void testPartialUpdatePhoneUnchanged() {
        Contact contact = new Contact("C012", "Eve", "Jones", "2233445566", "654 Spruce Blvd");
        
        service.addContact(contact);
        service.updateContact("C012", "Evelyn", null, null, "New Address");
        
        assertEquals("2233445566", contact.getPhone(), "Phone should remain unchanged");
    }

    @Test
    @DisplayName("Test partial update changes first name")
    void testPartialUpdateFirstName() {
        Contact contact = new Contact("C012", "Eve", "Jones", "2233445566", "654 Spruce Blvd");
        
        service.addContact(contact);
        service.updateContact("C012", "Evelyn", null, null, "New Address");
        
        assertEquals("Evelyn", contact.getFirstName(), "First name should be updated");
    }

    @Test
    @DisplayName("Test partial update changes address")
    void testPartialUpdateAddress() {
        Contact contact = new Contact("C012", "Eve", "Jones", "2233445566", "654 Spruce Blvd");
        
        service.addContact(contact);
        service.updateContact("C012", "Evelyn", null, null, "New Address");
        
        assertEquals("New Address", contact.getAddress(), "Address should be updated");
    }

    @Test
    @DisplayName("Test update non-existent contact")
    void testUpdateNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> 
            service.updateContact("INVALID_ID", "Evelyn", "Smith", "3344556677", "New Address"), 
            "Updating non-existent contact should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test update with invalid first name")
    void testUpdateWithInvalidFirstName() {
        Contact contact = new Contact("C012", "Eve", "Jones", "2233445566", "654 Spruce Blvd");
        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> 
            service.updateContact("C012", "EvelynJunior", null, null, null), 
            "Updating with first name > 10 chars should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test update with invalid phone")
    void testUpdateWithInvalidPhone() {
        Contact contact = new Contact("C012", "Eve", "Jones", "2233445566", "654 Spruce Blvd");
        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> 
            service.updateContact("C012", null, null, "12345", null), 
            "Updating with phone < 10 digits should throw IllegalArgumentException");
    }
}
package com.mobileapp.contactservice;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Contact class, verifying constructor validation and getters.
 */
class ContactTest {

    @Test
    @DisplayName("Test contact creation with valid contact ID")
    void testValidContactId() {
        Contact contact = new Contact("C123", "Alice", "Smith", "1234567890", "123 Maple Street");
        assertEquals("C123", contact.getContactId(), "Contact ID should match");
    }

    @Test
    @DisplayName("Test contact creation with valid first name")
    void testValidFirstName() {
        Contact contact = new Contact("C123", "Alice", "Smith", "1234567890", "123 Maple Street");
        assertEquals("Alice", contact.getFirstName(), "First name should match");
    }

    @Test
    @DisplayName("Test contact creation with valid last name")
    void testValidLastName() {
        Contact contact = new Contact("C123", "Alice", "Smith", "1234567890", "123 Maple Street");
        assertEquals("Smith", contact.getLastName(), "Last name should match");
    }

    @Test
    @DisplayName("Test contact creation with valid phone")
    void testValidPhone() {
        Contact contact = new Contact("C123", "Alice", "Smith", "1234567890", "123 Maple Street");
        assertEquals("1234567890", contact.getPhone(), "Phone should match");
    }

    @Test
    @DisplayName("Test contact creation with valid address")
    void testValidAddress() {
        Contact contact = new Contact("C123", "Alice", "Smith", "1234567890", "123 Maple Street");
        assertEquals("123 Maple Street", contact.getAddress(), "Address should match");
    }

    @Test
    @DisplayName("Test contact creation with null contact ID")
    void testNullContactId() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact(null, "Bob", "Lee", "0987654321", "456 Oak Ave"),
            "Null contact ID should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test contact creation with contact ID exceeding 10 characters")
    void testLongContactId() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("C12345678901", "Bob", "Lee", "0987654321", "456 Oak Ave"),
            "Contact ID longer than 10 characters should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test contact creation with null first name")
    void testNullFirstName() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("C456", null, "Taylor", "1234567890", "789 Pine Rd"),
            "Null first name should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test contact creation with first name exceeding 10 characters")
    void testLongFirstName() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("C456", "AlexanderJr", "Taylor", "1234567890", "789 Pine Rd"),
            "First name longer than 10 characters should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test contact creation with null last name")
    void testNullLastName() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("C456", "Carol", null, "1234567890", "789 Pine Rd"),
            "Null last name should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test contact creation with last name exceeding 10 characters")
    void testLongLastName() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("C456", "Carol", "Taylor-Smith", "1234567890", "789 Pine Rd"),
            "Last name longer than 10 characters should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test contact creation with null phone")
    void testNullPhone() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("C456", "Carol", "Taylor", null, "789 Pine Rd"),
            "Null phone should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test contact creation with phone less than 10 digits")
    void testShortPhone() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("C456", "Carol", "Taylor", "1234", "789 Pine Rd"),
            "Phone less than 10 digits should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test contact creation with phone more than 10 digits")
    void testLongPhone() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("C456", "Carol", "Taylor", "12345678901", "789 Pine Rd"),
            "Phone more than 10 digits should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test contact creation with non-numeric phone")
    void testNonNumericPhone() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("C456", "Carol", "Taylor", "123abc4567", "789 Pine Rd"),
            "Non-numeric phone should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test contact creation with null address")
    void testNullAddress() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("C456", "Carol", "Taylor", "1234567890", null),
            "Null address should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Test contact creation with address exceeding 30 characters")
    void testLongAddress() {
        String longAddress = "1234567890123456789012345678901"; // 31 characters
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("C456", "Carol", "Taylor", "1234567890", longAddress),
            "Address longer than 30 characters should throw IllegalArgumentException");
    }
    
    @Test
    @DisplayName("Test setting valid first name")
    void testSetValidFirstName() {
        Contact contact = new Contact("C123", "Alice", "Smith", "1234567890", "123 Maple Street");
        contact.setFirstName("Bob");
        assertEquals("Bob", contact.getFirstName(), "First name should be updated");
    }

    @Test
    @DisplayName("Test setting valid last name")
    void testSetValidLastName() {
        Contact contact = new Contact("C123", "Alice", "Smith", "1234567890", "123 Maple Street");
        contact.setLastName("Jones");
        assertEquals("Jones", contact.getLastName(), "Last name should be updated");
    }

    @Test
    @DisplayName("Test setting valid phone")
    void testSetValidPhone() {
        Contact contact = new Contact("C123", "Alice", "Smith", "1234567890", "123 Maple Street");
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone(), "Phone should be updated");
    }

    @Test
    @DisplayName("Test setting valid address")
    void testSetValidAddress() {
        Contact contact = new Contact("C123", "Alice", "Smith", "1234567890", "123 Maple Street");
        contact.setAddress("456 Oak Ave");
        assertEquals("456 Oak Ave", contact.getAddress(), "Address should be updated");
    }
}